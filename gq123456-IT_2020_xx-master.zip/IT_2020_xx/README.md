[java面试宝典和后端技术学习指南](<https://github.com/OUYANGSIHAI/JavaInterview>)

[CSDN](<https://blog.csdn.net/baidu_33094261>)

